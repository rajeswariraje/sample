package com.jouve.ctrl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jouve.dao.UserDao;
import com.jouve.model.User;

@Controller
public class ManagerUserCtrl {

	@Autowired
	UserDao userDao;

	@RequestMapping(value = "/viewAll", method=RequestMethod.GET)
	public String viewAll(Model model) {
		List<User> list = userDao.viewAll();
		//System.out.println(list);
		model.addAttribute("userList", list);
		return "viewAll";
	}

	@RequestMapping(value = "/search", method=RequestMethod.GET)
	public String searchGet(Model model) {
		model.addAttribute("");
		return "search";
	}

	@RequestMapping(value = "/search", method=RequestMethod.POST)
	public String searchPost(HttpServletRequest request, Model model) {
		String pathValue = request.getParameter("userName");
		List<User> list = userDao.searchByUserName(pathValue);
		//System.out.println(list);
		model.addAttribute("userList", list);
		return "viewAll";
	}

	@RequestMapping(value="/find/{userId}", method=RequestMethod.GET)
	public String findUser(@PathVariable("userId") Integer userId, Model model) {
		User user = userDao.find(userId);
		model.addAttribute("user", user);
		return "find";
	}
}
