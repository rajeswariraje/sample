package com.jouve.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jouve.dao.UserDao;
import com.jouve.model.User;
import com.jouve.validator.LoginValidator;

@Controller
public class LoginController {

	@Autowired
	UserDao userDao;

	@Autowired
	LoginValidator loginValidator;

	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String login(Model model) {
		model.addAttribute("user", new User());
		return "login";
	}

	@RequestMapping(value="/loginProcess", method = RequestMethod.POST)
	public String loginProcess(@ModelAttribute("login") User userModel, BindingResult result, Model model) {

		//Validation
		loginValidator.validate(userModel, result);

		if(result.hasErrors()) {
			return "login";
		}

		User user = userDao.validateUser(userModel);
		if(user != null)
			model.addAttribute("message", user.getFirstName()+" login successfully");
		else
			model.addAttribute("message", "Invalid username or password");

		return "welcome";
	}
}
