package com.jouve.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jouve.dao.UserDao;
import com.jouve.model.User;
import com.jouve.validator.UserValidator;

@Controller
public class RegistrationController {

	@Autowired
	UserDao userDao;

	@Autowired
	UserValidator userValidator;


	@RequestMapping(value="/register", method = RequestMethod.GET)
	public String register(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	@RequestMapping(value="/registerProcess", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("user") User user, BindingResult result, Model model) {

		userValidator.validate(user, result);

		if(result.hasErrors()) {
			return "register";
		}

		int pk = userDao.register(user);

		model.addAttribute("message", user.getUserName() + " username successfully created with primary key: "+pk);
		return "welcome";
	}
}
