package com.jouve.daoImpl;


import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.jouve.dao.UserDao;
import com.jouve.model.User;
import com.jouve.utility.HibernateUtil;

@Repository
public class UserDaoImpl implements UserDao{

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public int register(User user) {

		/*String sql = "insert into users values(?,?,?,?,?,?,?)";
		Object[] parameter = {user.getUserName(), user.getPassword(), user.getFirstName(), user.getLastName(), user.getEmail(),
				user.getAddress(), user.getPhone()};
		return jdbcTemplate.update(sql,parameter);*/

		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int pk = 0;
		try {
			pk = (int) session.save(user);
			tr.commit();
		} catch(Exception e) {
			tr.rollback();
			System.err.println("Failed to insert "+e);
		} finally {
			session.close();
		}
		return pk;

	}

	@Override
	public User validateUser(User user) {
		/*String sql = "select * from users where username='" + user.getUserName() + "' and password='" + user.getPassword()
        + "'";
		List<User> users = jdbcTemplate.query(sql, new UserMapper());
		return users.size() > 0 ? users.get(0) : null;*/

		Session session = sessionFactory.openSession();
		Transaction tr =  session.beginTransaction();

		//Using criteria
		/*Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("userName", user.getUserName()));
		cr.add(Restrictions.eq("password", user.getPassword()));
		List<User> users = cr.list();*/

		//Using Query
		Query query = session.createQuery("from User where userName= :username and password=:password");
		query.setParameter("username", user.getUserName());
		query.setParameter("password", user.getPassword());
		List<User> users = query.getResultList();
		tr.commit();
		session.close();
		return users.size() > 0 ? users.get(0) : null;
	}

	@Override
	public List<User> viewAll() {
		Session session = sessionFactory.openSession();
		//Criteria cr = session.createCriteria(User.class);
		//List<User> list = cr.list();
		List list = session.createQuery("from User").list();
		return list;
	}

	@Override
	public List<User> searchByUserName(String userName){

		Session session = sessionFactory.openSession();

		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.like("userName", "%"+userName+"%"));
		List<User> users = cr.list();

		return users;
	}

	public User find(Integer id) {
		Session session = sessionFactory.openSession();
		User user = session.load(User.class, id);
		return user;
	}
}