package com.jouve.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.jouve.model.User;

public class UserValidator implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.userName", "userName is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.password", "password is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "firstName", "error.firstName", "firstName is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "lastName", "error.lastName", "lastName is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "email", "error.email", "email is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "address", "error.address", "address is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "phone", "error.phone", "phone is required");
	}
	
}
