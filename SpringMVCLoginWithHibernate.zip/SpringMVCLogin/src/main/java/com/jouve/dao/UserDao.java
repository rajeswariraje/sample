package com.jouve.dao;

import java.util.List;

import com.jouve.model.User;

public interface UserDao {

	public int register(User user);

	public User validateUser(User user);

	public List<User> viewAll();

	public List<User> searchByUserName(String userName);

	public User find(Integer id);
}
