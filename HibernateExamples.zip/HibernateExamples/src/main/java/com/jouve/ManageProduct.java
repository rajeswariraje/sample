package com.jouve;

import java.util.List;
import java.util.Iterator;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ManageProduct {
   private static SessionFactory factory;
   public static void main(String[] args) {

      try {
         factory = new Configuration().configure().buildSessionFactory();

      } catch (Throwable ex) {
         System.err.println("Failed to create sessionFactory object." + ex);
         throw new ExceptionInInitializerError(ex);
      }

      ManageProduct MP = new ManageProduct();

      /* Add few Products in database */
      Integer prod1 = MP.addProduct("Pears", "Soap", 67);
      Integer prod2 = MP.addProduct("Idayam", "oil", 150);
      Integer prod3 = MP.addProduct("Ponds", "Powder", 100);

      /* List down all the Products */
      MP.listProducts();

      /* Update Product records */
      MP.updateProductCost(prod1, 500);

      /* Delete an Product from the database */
      MP.deleteProduct(prod2);

      /* List down new list of the Products */
      MP.listProducts();
   }

   /* Method to CREATE an Product in the database */
   public Integer addProduct(String pname, String ptype, int pcost){
      Session session = factory.openSession();
      Transaction tx = null;
      Integer productID = null;

      try {
         tx = session.beginTransaction();
         Product product = new Product(pname, ptype, pcost);
         productID = (Integer) session.save(product);
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace();
      } finally {
         session.close();
      }
      return productID;
   }

   /* Method to  READ all the Products */
   public void listProducts( ){
      Session session = factory.openSession();
      Transaction tx = null;

      try {
         tx = session.beginTransaction();
         List products = session.createQuery("FROM Product").list();
         for (Iterator iterator = products.iterator(); iterator.hasNext();){
            Product product = (Product) iterator.next();
            System.out.print("Product Name: " + product.getProductName());
            System.out.print("\tProduct Type: " + product.getProductType());
            System.out.println("\tProduct Cost: " + product.getProductCost());
         }
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace();
      } finally {
         session.close();
      }
   }

   /* Method to UPDATE ProductCost for an Product */
   public void updateProductCost(Integer productID, int productCost ){
      Session session = factory.openSession();
      Transaction tx = null;

      try {
         tx = session.beginTransaction();
         Product product = session.get(Product.class, productID);
         product.setProductCost( productCost );
		 session.update(product);
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace();
      } finally {
         session.close();
      }
   }

   /* Method to DELETE an Product from the records */
   public void deleteProduct(Integer productID){
      Session session = factory.openSession();
      Transaction tx = null;

      try {
         tx = session.beginTransaction();
         Product product = session.get(Product.class, productID);
         session.delete(product);
         tx.commit();
      } catch (HibernateException e) {
         if (tx!=null) tx.rollback();
         e.printStackTrace();
      } finally {
         session.close();
      }
   }
}