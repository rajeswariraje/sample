package com.jouve;

public class Product implements java.io.Serializable{
   /**
	 *
	 */
   private static final long serialVersionUID = 1L;
   private int productID;
   private String productName;
   private String productType;
   private int productCost;

   public Product() {}
   public Product(String productName, String productType, int productCost) {
      this.productName = productName;
      this.productType = productType;
      this.productCost = productCost;
   }

   public int getProductID() {
      return productID;
   }

   public void setProductID( int product_id ) {
      this.productID = product_id;
   }

   public String getProductName() {
      return productName;
   }

   public void setProductName( String product_name ) {
      this.productName = product_name;
   }

   public String getProductType() {
      return productType;
   }

   public void setProductType( String product_type ) {
      this.productType = product_type;
   }

   public int getProductCost() {
      return productCost;
   }

   public void setProductCost( int product_cost ) {
      this.productCost = product_cost;
   }
}