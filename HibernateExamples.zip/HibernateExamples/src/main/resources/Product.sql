create table PRODUCT (
   product_id INT NOT NULL auto_increment,
   product_name VARCHAR(20) default NULL,
   product_type  VARCHAR(20) default NULL,
   product_cost     INT  default NULL,
   PRIMARY KEY (id)
);