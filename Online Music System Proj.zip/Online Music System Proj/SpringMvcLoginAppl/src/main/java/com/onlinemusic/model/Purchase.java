package com.onlinemusic.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import javax.persistence.Table;

@Entity
@Table(name = "PURCHASE")
public class Purchase {
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="Purchase_ID",nullable=false)
	private int purchase_id;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="songID",nullable=false)
	private Song song;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="id",nullable=false)
	private User user;

	public int getPurchase_id() {
		return purchase_id;
	}

	public void setPurchase_id(int purchase_id) {
		this.purchase_id = purchase_id;
	}

	public Song getSong() {
		return song;
	}

	public void setSong(Song song) {
		this.song = song;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
	
	
	
	
