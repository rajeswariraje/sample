package com.onlinemusic.validator;

import org.springframework.validation.Errors;

import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;

import com.onlinemusic.model.User;
/**
 * @author Rajeswari
 *This Class is used for Validation of user details
 */
@Validated
public class UserValidator implements Validator {

@Override
	public boolean supports(Class<?> clazz) {
		
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		User user = (User) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Name", "error.Name", "*Please Enter your Name");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Address", "error.Address", "*Please Enter your Address ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "City", "error.City", "*Please Enter your City ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "State", "error.State", "*Please Enter your State");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "gender", "error.gender","*Please Select your Gender");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "mobileNumber", "error.mobileNumber","*Please Provide your Mobile Number");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "SecretQuestion", "error.SecretQuestion", "*Please Enter your Secret Question");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "SecretAnswer", "error.SecretAnswer", "*Please Enter your Secret Answer");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "UserName", "error.UserName", "*Please Enter your User Name ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "Password", "error.Password", "*Please Enter your Password");
		
		if(errors.getFieldError("UserName") == null && user.getUserName().length()<1) {
			errors.rejectValue("UserName", "error.UserName", "User Name lengh should be greater than 1");
	}
	 if(errors.getFieldError("SecretQuestion") == null && user.getSecretQuestion().length()<3) {
			errors.rejectValue("SecretQuestion", "error.SecretQuestion", "Secret Question lengh should be greater than 3");
		}
		if(errors.getFieldError("SecretAnswer") == null && user.getSecretAnswer().length()<2) {
			errors.rejectValue("SecretAnswer", "error.SecretAnswer", "Secret Answer lengh should be greater than 2");
		}
		if(errors.getFieldError("Password") == null && user.getPassword().length()<5) {
			errors.rejectValue("Password", "error.Password", "Password lengh should be greater than 5");
		}
		if(errors.getFieldError("City") == null && user.getCity().length()<2) {
			errors.rejectValue("City", "error.City", "City lengh should be greater than 2");
		}
		if(errors.getFieldError("State") == null && user.getState().length()<5) {
			errors.rejectValue("State", "error.State", "State lengh should be greater than 5");
		}
		if(errors.getFieldError("Name") == null && user.getName().length()<=2) {
			errors.rejectValue("Name", "error.Name", "Name lengh should be greater than 2");
		}
		if(errors.getFieldError("mobileNumber") == null && user.getMobileNumber().length()<10 || user.getMobileNumber().length()>10) {
			errors.rejectValue("mobileNumber", "error.mobileNumber", "Mobile Number length should not be greater or less than 10");
		}
		
	
	}}
