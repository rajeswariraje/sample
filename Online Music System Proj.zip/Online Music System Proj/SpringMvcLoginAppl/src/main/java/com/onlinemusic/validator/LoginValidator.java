package com.onlinemusic.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.validation.annotation.Validated;

import com.onlinemusic.model.User;

/**
 * @author Rajeswari
 *This class is used for LoginValidation
 */
@Validated
public class LoginValidator implements Validator {

	
	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		User login = (User) target;
		System.out.println("Validation started");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.userName", "User Name is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.password", "Password is required");
		if (errors.getFieldError("userName") == null && login.getUserName().length() < 3) {
			errors.rejectValue("userName", "error.userName", "User Name length should be greater than 3");

		} else if (errors.getFieldError("password") == null && login.getPassword().length() < 3) {
			errors.rejectValue("password", "error.password", "password length should be greater than 3");
		}
		System.out.println("Validation working");
	}

}
