package com.onlinemusic.cntrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinemusic.model.Admin;
import com.onlinemusic.validator.AdminValidator;




/**
 * @author Rajeswari
 *This class is used for Admin Login
 */


@Controller

public class AdminController {

	@Autowired
	AdminValidator adminValidator;
	/**
	 * @param model
	 * @return managedetails
	 */
	@RequestMapping(value = "/adminProcess", method = RequestMethod.GET)
	
	public String admin(Model model) {
		model.addAttribute("admin", new Admin());
		return "managedetails";
	}

	/**
	 * @param model
	 * @return admin
	 */
	@RequestMapping(value = "/Admin", method = RequestMethod.GET)
	
	public String Admin(Model model) {
		model.addAttribute("admin", new Admin());
		return "admin";
	}

	/**
	 * @param admin
	 * @param result
	 * @param model
	 * @return managedetails
	 */
	@RequestMapping(value = "/Admin", method = RequestMethod.POST)
	
	public String login(@ModelAttribute("admin") Admin admin, BindingResult result, Model model) {
		System.out.println("Post method working");
		adminValidator.validate(admin, result);
		if (result.hasErrors()) {
			model.addAttribute("message", "!!Please Enter User Name and Password , it cannot be empty");
			return "admin";
		}
		System.out.println("Validation completed");
		if (admin.getAdmin_Id() == 5006 && admin.getPassword().equals("raje")) {
			return "managedetails";
		} else
			model.addAttribute("message", "!!Please Provide a Correct  User Name or Password");
		return "admin";

	}
}