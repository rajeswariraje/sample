package com.onlinemusic.daoImpl;

import java.util.List;

import javax.persistence.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.stereotype.Repository;


import com.onlinemusic.Utility.HibernateUtil;
import com.onlinemusic.dao.SongDao;
import com.onlinemusic.model.Song;

@SuppressWarnings("unchecked")

@Repository
public class SongDaoImpl implements SongDao {
	
	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public int songregister(Song song) {		//Registering Song Details
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int pk =0;
		try {
			pk = (int) session.save(song);
			tr.commit();
		} catch(Exception e) {
			tr.rollback();
			System.err.println("Failed to insert "+e);
		} finally {
			session.close();
		}
		return pk;
		
	}
	@Override
	public Song viewsong(int songID) {			//Displaying the Particular Song Detail
		Session session = sessionFactory.openSession();
		Song song = session.get(Song.class, songID);
		return song;
		
	}

	@Override
	public Song delete(int songID) {			//Removing the Particular Song Detail
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Song song = (Song)session.get(Song.class, songID);
		Query query = session.createQuery("UPDATE Song SET active=:active WHERE songID=:songID");
		query.setParameter("songID", songID);
		query.setParameter("active", false);
		query.executeUpdate();
		tr.commit();
		session.close();
		System.out.println("Successfully deleted");
		return song;
	
	}
	
	@Override
	public List<Song> viewallsongs() {		//Displaying All the Song Details
		Session session = sessionFactory.openSession();
		List<Song> list = session.createQuery("from Song  WHERE active IS TRUE").list();
		return list;
	
	}

	@Override
	public Song updatesong(int songID, String songCost, String rating) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Song song =(Song)session.get(Song.class,songID);
		if(song!=null) {
			song.setSongCost(songCost);
			song.setRating(rating);
			session.update(song);
			tr.commit();
			session.close();
			System.out.println("Successfully updated");
			return song;
		}
		else {
			return null;
		}
	}
	@Override
	public String removesong(int songID) {  //Removing in viewallsongs details
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Song song = (Song)session.get(Song.class, songID);
		Query query = session.createQuery("delete from Purchase where song=:song");
		query.setParameter("song", song);
		query.executeUpdate();
		session.delete(song);
		tr.commit();
		session.close();
		System.out.println("Successfully deleted");
		return null;
	}
	@Override
	public Song update(int songID, String songCost, String rating) {
			Session session = sessionFactory.openSession();
			Transaction tr = session.beginTransaction();
			Song song =(Song)session.get(Song.class,songID);
			if(song!=null) {
				song.setSongCost(songCost);
				song.setRating(rating);
				session.update(song);
				tr.commit();
				session.close();
				System.out.println("Successfully updated");
				return song;
			}
			else {
				return null;
			}
		}
}