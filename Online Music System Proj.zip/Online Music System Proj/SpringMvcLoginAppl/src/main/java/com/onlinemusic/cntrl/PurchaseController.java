package com.onlinemusic.cntrl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinemusic.dao.PurchaseDao;
import com.onlinemusic.dao.SongDao;
import com.onlinemusic.model.Admin;
import com.onlinemusic.model.Purchase;
import com.onlinemusic.model.Song;


/**
 * @author Rajeswari
 *This class is used for Purchase
 */
@Controller
public class PurchaseController {
	
	@Autowired
	PurchaseDao purchaseDao;
	
	@Autowired
	SongDao songDao;

	/**
	 * @param model
	 * @return buysong
	 */
	@RequestMapping(value = "/buysong", method = RequestMethod.GET)
	public String buysong(Model model) {
		List<Song> list = songDao.viewallsongs();
		model.addAttribute("song", null);
		model.addAttribute("songList", list);
		return "buysong";

	}
	
	/**
	 * @param request
	 * @param model
	 * @return buysong
	 */
	@RequestMapping(value = "/buysong", method = RequestMethod.POST)
	public String viewBeforeBuysong(HttpServletRequest request, Model model) {
		String songId= request.getParameter("mySelect");
		Song song = songDao.viewsong(Integer.parseInt(songId));
		List<Song> list = songDao.viewallsongs();
		model.addAttribute("song", song);
		model.addAttribute("songList", list);
		return "buysong";
	}
	
	


	
	/**
	 * @param request
	 * @param model
	 * @return Purchase
	 */
	@RequestMapping(value = "/purchase", method = RequestMethod.POST)
	public String purchaseSong(HttpServletRequest request, Model model) {
		List<Song> list = songDao.viewallsongs();
		model.addAttribute("song", null);
		model.addAttribute("songList", list);
		
		String songId= request.getParameter("mySelect");
		Song song = songDao.viewsong(Integer.parseInt(songId));
		HttpSession session = request.getSession(true);
		String userName = (String)session.getAttribute("user"); 
		Purchase purchase = purchaseDao.purchase(userName,song);
		if(purchase==null) {
			model.addAttribute("message", "This song has been already purchased"); 
			return "buysong";
		} 
		else {
			model.addAttribute("message", "You have been  purchased this song Successfully"); 
			return "buysong";
		}
	}

	/**
	 * @param request
	 * @param model
	 * @return viewallyourpurchasedsongs
	 */
	@RequestMapping(value = "/viewallyourpurchasedsongs", method = RequestMethod.GET)
	public String viewallyourpurchasedsongs(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession(true);
		String userName = (String)session.getAttribute("user"); 
		List<Purchase> list = purchaseDao.viewallyourpurchasedsongs(userName);
		model.addAttribute("purchaselist", list); 
		return "viewallyourpurchasedsongs";
	}
	
	/**
	 * @param request
	 * @param model
	 * @return viewpurchasedsongs
	 */
	@RequestMapping(value = "/viewpurchasedsongs", method = RequestMethod.GET)
	public String viewpurchasedsongs(HttpServletRequest request, Model model) {
		HttpSession session = request.getSession();
		String userName = (String)session.getAttribute("user"); 
		List<Purchase> list = purchaseDao.viewallyourpurchasedsongs(userName);
		model.addAttribute("purchaselist", list);
		return "viewpurchasedsongs";
	}


}
