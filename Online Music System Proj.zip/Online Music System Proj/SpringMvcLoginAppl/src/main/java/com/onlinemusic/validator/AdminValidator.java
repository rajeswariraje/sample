package com.onlinemusic.validator;


import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.onlinemusic.model.Admin;

/**
 * @author Rajeswari
 *This Class is used for Admin Validation
 */
public class AdminValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Admin.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "admin_Id", "error.admin_Id", "*please enter your admin_Id");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.password", "*please enter your password ");
	}
}