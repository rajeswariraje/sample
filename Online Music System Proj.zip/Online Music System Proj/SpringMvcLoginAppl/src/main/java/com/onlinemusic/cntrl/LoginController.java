package com.onlinemusic.cntrl;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinemusic.dao.UserDao;
import com.onlinemusic.model.User;
import com.onlinemusic.validator.LoginValidator;


/**
 * @author Rajeswari
 *This class is used for Login
 */
@Controller
public class LoginController {

	@Autowired
	UserDao userDao;

	@Autowired
	LoginValidator loginValidator;

	/**
	 * @param model
	 * @return login
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	
	public String login(Model model) {
		model.addAttribute("login", new User());
		return "login";
	}
	
@RequestMapping(value = "/managepurchase", method = RequestMethod.GET)
	
	public String managepurchase(Model model) {
		model.addAttribute("login", new User());
		return "Purchase";
	}

	/**
	 * @param login
	 * @param result
	 * @param model
	 * @param request
	 * @return Purchase
	 */
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	
	public String login(@ModelAttribute("login") User login, BindingResult result, Model model,
			HttpServletRequest request) {
		System.out.println("Post method working");
		loginValidator.validate(login, result);
		if (result.hasErrors()) {
			model.addAttribute("message", "!!Please Enter User Name and Password , it cannot be empty");
			return "login";
		}
		System.out.println("Validation completed");
		User user = userDao.validateUser(login);
		if (user != null&&user.isActive()) {
			HttpSession session = request.getSession(true);
			session.setAttribute("user", user.getUserName());
			session.setAttribute("Active", login.isActive());
			model.addAttribute("message", user.getUserName() + "\nSUCCESSFULL LOGIN");
			return "Purchase";
		}
		else if(user != null&& !user.isActive()) {
			model.addAttribute("message", "User Name you are trying to login is inactive!!");
		return "login";
		
	}
		else {
			model.addAttribute("message", "!!Please Provide Correct User Name and Password!!");
		return "login";
	}

}
}