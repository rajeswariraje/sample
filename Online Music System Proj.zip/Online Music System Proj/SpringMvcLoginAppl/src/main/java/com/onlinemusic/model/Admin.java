package com.onlinemusic.model;

public class Admin {
			private int admin_Id;
			private String password;
			public int getAdmin_Id() {
				return admin_Id;
			}
			public void setAdmin_Id(int admin_Id) {
				this.admin_Id = admin_Id;
			}
			public String getPassword() {
				return password;
			}
			public void setPassword(String password) {
				this.password = password;
			}

	

}
