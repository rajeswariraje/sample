package com.onlinemusic.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "song")
public class Song {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "songID")
	private int songID;
	
	@Column(name = "songName")
	private String songName;
	
	@Column(name = "songType")
	private String songType;
	
	@Column(name = "songCost")
	private String songCost;
	
	@Column(name = "songDuration")
	private String songDuration;
	
	@Column(name = "movieName")
	private String movieName;
	
	@Column(name = "Rating")
	private String rating;
	
	@Column(name="Active",nullable=false)
	private boolean active;
	

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getSongID() {
		return songID;
	}

	public void setSongID(int songID) {
		this.songID = songID;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public String getSongType() {
		return songType;
	}

	public void setSongType(String songType) {
		this.songType = songType;
	}

	public String getSongCost() {
		return songCost;
	}

	public void setSongCost(String songCost) {
		this.songCost = songCost;
	}

	public String getSongDuration() {
		return songDuration;
	}

	public void setSongDuration(String songDuration) {
		this.songDuration = songDuration;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}


	@Override
	public boolean equals(Object obj) {
		Song song = (Song) obj;
		if(this.songID == song.songID)
			return true;
		else
			return false;
	}
	
	

	

}
