package com.onlinemusic.daoImpl;

import java.util.List;

import javax.persistence.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.stereotype.Repository;

import com.onlinemusic.Utility.HibernateUtil;
import com.onlinemusic.dao.UserDao;
import com.onlinemusic.model.User;

@SuppressWarnings("unchecked")
@Repository
public class UserDaoImpl implements UserDao {

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public int register(User user) {		//Registering the User Details
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int pk = (int) session.save(user);
		tr.commit();
		return pk;
	}

	@Override
	public User validateUser(User user) {  //Validation for Login
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Query query = session.createQuery("from User where userName= :username and password=:password");
		query.setParameter("username", user.getUserName());
		query.setParameter("password", user.getPassword());
		List<User> users = query.getResultList();
		tr.commit();
		session.close();
		return users.size() > 0 ? users.get(0) : null;
	}

	@Override
	public String deleteuser(String userName) {		//Removing User Details
			Session session = sessionFactory.openSession();				
			Transaction tr = session.beginTransaction();
			Query query = session.createQuery("UPDATE User SET active=:active WHERE userName=:userName");
			query.setParameter("userName",userName);
			query.setParameter("active",false);
			int recordCount = query.executeUpdate();
			tr.commit();
			session.close();
			System.out.println("Successfully deleted");
			if(recordCount > 0) {
				return null;
			}
			return "user";
	}

	
	@Override
	public List<User> viewAllusers() {    //Displaying all Records of the  User
		Session session = sessionFactory.openSession();
		 List<User> list = session.createQuery("from User WHERE active IS TRUE").list();
		return list;

	}

	@Override
	public List<User> search(String userName) {			//Searching  the Particular Record
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where active IS TRUE AND userName like :userName");
		query.setParameter("userName", "%"+userName+"%");
		List<User> users=query.getResultList();
		return users;
	}

	@Override
	public User UserValidation(User user) {			//MobileNumber and UserName Validation  
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Query query = session.createQuery("from User where userName= :username OR mobileNumber=:mobileNumber");
		query.setParameter("username", user.getUserName());
		query.setParameter("mobileNumber", user.getMobileNumber());
		List<User> users = query.getResultList();
		/*for(User userItr:users) {
			if(userItr.getUserName().equals(user.getUserName())){
				return "userName";
			}
			else if(userItr.getMobileNumber().equals(user.getMobileNumber())){
				return "mobileNumber";
			}
		
		}*/
		tr.commit();
		return users.size() > 0 ? users.get(0) : null;
	}
	
	@Override
	public User updateusercredentials(User user) {		//Updating User Credentials
		try {
			Session session = sessionFactory.openSession();
			Transaction tr = session.beginTransaction();
			Query query = session.createQuery("UPDATE User SET secretAnswer=:secretAnswer,password=:password WHERE userName=:userName");
			query.setParameter("userName", user.getUserName());
			query.setParameter("secretAnswer",user.getSecretAnswer());
			query.setParameter("password", user.getPassword());
			int status = query.executeUpdate();
			tr.commit();
			session.close();
			if(status == 0) {
				return null;
			}
		} catch(Exception e) {
			return null;
		}
		return user;
	}


	@Override
	public String removeuser(String userName) {		//Removing User Details
			Session session = sessionFactory.openSession();				
			Transaction tr = session.beginTransaction();
			Query query = session.createQuery("UPDATE User SET active=:active WHERE userName=:userName");
			query.setParameter("userName",userName);
			query.setParameter("active",false);
			//int recordCount = query.executeUpdate();
			query.executeUpdate();
			tr.commit();
			session.close();
			System.out.println("Successfully Deleted");
			/*if(recordCount > 0) {
				return null;
			}*/
			return null;
	}

}

	