package com.onlinemusic.cntrl;

import java.util.List;


import javax.servlet.http.HttpServletRequest;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinemusic.dao.UserDao;
import com.onlinemusic.model.User;
import com.onlinemusic.validator.UserValidator;

/**
 * @author Rajeswari
 *This Class is used for Managing User Details
 */
@Controller

public class ManageUserController {

	@Autowired
	UserDao userDao;

	@Autowired
	UserValidator userValidator;

	/**
	 * @param model
	 * @return Register
	 */
	@RequestMapping(value = "/register", method = RequestMethod.GET)
	
	public String register(Model model) {
		model.addAttribute("user", new User());
		return "register";
	}

	/**
	 * @param user
	 * @param result
	 * @param model
	 * @return Register
	 */
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	
	public String register(@ModelAttribute("user") User user, BindingResult result, Model model) {
		userValidator.validate(user, result);
	
		if (result.hasErrors()) {
			return "register";
		}
		user.setActive(true);
		User rUser = userDao.UserValidation(user);
		if(rUser==null) {
		userDao.register(user);
		model.addAttribute("message", user.getUserName() + " User Name successfully created");
		return "register";
		}
		else if(rUser.getMobileNumber().equals(user.getMobileNumber()) && rUser.getUserName().equals(user.getUserName())) {
				model.addAttribute("message", "You Are Not Allowed to Register,the Entered User Name And mobile Number Already Exists");	
		}
		else if (rUser.getMobileNumber().equals(user.getMobileNumber())) {
			model.addAttribute("message", "Mobile number already exists");
			
		}
		 else if (rUser.getUserName().equals(user.getUserName())) {
			model.addAttribute("message", "You Are Not Allowed to Register,the Entered User Name Already Exists");
			
		}
		return  "register";
	
	}
	/**
	 * @return updateusercredentials
	 */
	@RequestMapping(value = "/updateusercredentials", method = RequestMethod.GET)
	public String updateusercredentials() {
	return "updateusercredentials";
}
	/**
	 * @param request
	 * @param model
	 * @return updateusercredentials
	 */
	@RequestMapping(value = "/updateusercredentials", method = RequestMethod.POST)
	public String updateusercredentials(HttpServletRequest request, Model model) {
		String userName = request.getParameter("userName");
		String secretAnswer = request.getParameter("secretAnswer");
		String password = request.getParameter("password");
		User user = new User();
		user.setUserName(userName);
		user.setSecretAnswer(secretAnswer);
		user.setPassword(password);
		if (userName==null) {
			List<User> list = userDao.viewAllusers();
			model.addAttribute("userList",list);
			model.addAttribute("message", "Please Select to update the user crendentials details");
			return "viewallusers";
		}
		try {
			userName =request.getParameter("userName").toString();
			secretAnswer =request.getParameter("secretAnswer").toString();
			password = request.getParameter("password").toString();
		} catch (Exception e) {
			model.addAttribute("message", "User details not updated, please give a valid input..");
			return "updateusercredentials";
		}
		user.setActive(false);
		user = userDao.updateusercredentials(user);
		if ( user== null) {
			model.addAttribute("message", " Invalid.!! So not able to update the user details");
			return "updateusercredentials";
				} 
		else {
			model.addAttribute("message", "Successfully updated");
			return "updateusercredentials";
		}
		
	}
	
	/**
	 * @param model
	 * @return viewallusers
	 */
	@RequestMapping(value = "/viewallusers", method = RequestMethod.GET)
	public String viewallusers(Model model,HttpServletRequest request) {
		List<User> list = userDao.viewAllusers();
		model.addAttribute("userList", list);
		return "viewallusers";
	}

	/**
	 * @return deleteuser
	 */
	@RequestMapping(value = "/deleteuser", method = RequestMethod.GET)
	public String deleteuser() {
		return "deleteuser";
	}

	/**
	 * @param request
	 * @param model
	 * @return viewallusers
	 */
	@RequestMapping(value = "/deleteuser", method = RequestMethod.POST)
	public String deleteuser(HttpServletRequest request, Model model) {
		String userName = request.getParameter("userName").toString();
		if (userName.equals("")) {
			model.addAttribute("message", "Enter a valid username!!!!!!!!");
			return "deleteuser";
		}
		System.out.println("userName: " + userName);
		String status = userDao.deleteuser(userName);
		if (status!=null) {
			/*List<User> list = userDao.viewAllusers();
			model.addAttribute("userList", list);*/
			model.addAttribute("message", "UserName is not available!");
			return "deleteuser";
		} 
		else {
			model.addAttribute("message", "successfully deleted!!!!!!!");
			return "deleteuser";
		}

	}
	/**
	 * @return search
	 */
	@RequestMapping(value = "/search", method = RequestMethod.GET)
	public String viewuser() {
		return "search";
	}

	/**
	 * @param request
	 * @param model
	 * @return viewallusers
	 */
	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public String search(HttpServletRequest request, Model model) {
		String pathValue = request.getParameter("userName");
		if(pathValue.equals("")){
			model.addAttribute("message","Enter a Valid User Name for Search");
			return "search";
		}
		List<User> list = userDao.search(pathValue);
		model.addAttribute("userList",list);
		return "viewallusers";
	}
	
	
	@RequestMapping(value = "/removeuser", method = RequestMethod.GET)
	public String removeuser() {
		return "removeuser";
	}
	@RequestMapping(value = "/removeuser", method = RequestMethod.POST)
	public String removeuser(HttpServletRequest request, Model model) {
		String userName = request.getParameter("userName");
		if (userName==null) {
			List<User> list = userDao.viewAllusers();
			model.addAttribute("userList",list);
			model.addAttribute("message", "Please Select to remove the user details");
			return "viewallusers";
		}
		System.out.println("userName: " + userName);
		userDao.deleteuser(userName);
		model.addAttribute("message", "Successfully Deleted");
		return "removeuser";
		}

	}
	


