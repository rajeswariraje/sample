package com.onlinemusic.cntrl;


import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.onlinemusic.dao.SongDao;
import com.onlinemusic.model.Song;
import com.onlinemusic.model.User;
import com.onlinemusic.validator.SongValidator;

/**
 * @author Rajeswari
 * This class is used for Manage Song Details
 *
 */
@Controller
public class ManageSongController {

	@Autowired
	SongDao songDao;

	@Autowired
	SongValidator songValidator;
	

	/**
	 * @param model
	 * @return songregister
	 */
	@RequestMapping(value = "/songregister", method = RequestMethod.GET)
	
	public String songregister(Model model) {
		model.addAttribute("song", new Song());
		return "songregister";

	}

	/**
	 * @param song
	 * @param result
	 * @param model
	 * @return Song Register
	 */
	@RequestMapping(value = "/songregister", method = RequestMethod.POST)
	public String sidongregister(@ModelAttribute("song") Song song, BindingResult result, Model model) {
		
		songValidator.validate(song, result);

		if (result.hasErrors()) {
			return "songregister";
		}
		song.setActive(true);
		int pk = songDao.songregister(song);

		model.addAttribute("message", song.getSongName() + "SongName successfully created with primary key: " + pk);
		return "songregister";
	}

	
	/**
	 * @return Update Song Credentials
	 */
	@RequestMapping(value = "/updatesongcredentials", method = RequestMethod.GET)
	
	public String updatesong() {
		return "update";
	}

	/**
	 * @param request
	 * @param model
	 * @return Update Song Credentials
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	
	public String updatesong(HttpServletRequest request, Model model) {
		int songID;
		try {
			songID = Integer.parseInt(request.getParameter("songID").toString());
		} catch (Exception e) {
			List<Song> list = songDao.viewallsongs();
			model.addAttribute("songList", list);
			model.addAttribute("message", "Song details not updated, please give valid input..");
			return "viewallsongs";
		}
		Song song = songDao.viewsong(songID);
		model.addAttribute("song", song);
		return "update";
		
	}
	
	
	
	@RequestMapping(value = "/updatesong", method = RequestMethod.POST)
	public String update(HttpServletRequest request, Model model) {
	int songID = Integer.parseInt(request.getParameter("songID").toString());
	String songCost =request.getParameter("songCost");
	String rating = request.getParameter("rating");
	songDao.updatesong(songID, songCost, rating);
	List<Song> list = songDao.viewallsongs();
	model.addAttribute("songList", list);
//	model.addAttribute("message", "Successfully updated");
	return "viewallsongs";
		}
	/**
	 * @param model
	 * @return view All songs
	 */
	@RequestMapping(value = "/viewallsongs", method = RequestMethod.GET)
	
	public String viewallsongs(Model model) {
		List<Song> list = songDao.viewallsongs();
		model.addAttribute("songList", list);
		return "viewallsongs";
	}

	/**
	 * @param model
	 * @return View Song
	 */
	@RequestMapping(value = "/viewsong", method = RequestMethod.GET)
	public String viewsong(Model model) {
		model.addAttribute("song", new Song());
		return "viewsong";
	}


	/**
	 * @param model
	 * @return Delete Song
	 */
	@RequestMapping(value = "/deletesong", method = RequestMethod.GET)
	
	public String deletesong(Model model) {
		List<Song> list = songDao.viewallsongs();
		model.addAttribute("songList", list);
		return "deletesong";
	}

	/**
	 * @param request
	 * @param model
	 * @return View All Songs
	 */
	@RequestMapping(value = "/deletesong", method = RequestMethod.POST)
	
	public String deletesong(HttpServletRequest request, Model model) {
		int songID = Integer.parseInt(request.getParameter("mySelect"));
		Song song;
		song = songDao.delete(songID);
		if (song == null) {
			model.addAttribute("message", "Sorry, unable to delete the Song. Please try again");
			return "deletesong";
		} else {
			List<Song> list = songDao.viewallsongs();
			model.addAttribute("songList", list);
			return "viewallsongs";
		}

	}
	@RequestMapping(value = "/removesong", method = RequestMethod.GET)
	public String removesong(Model model) {
		/*List<Song> list = songDao.viewallsongs();
		model.addAttribute("songList", list);*/
		return "removesong";
		}
	
		@RequestMapping(value = "/removesong", method = RequestMethod.POST)
		public String removesong(HttpServletRequest request, Model model) {
			int songID ;
			try  {
				songID	= Integer.parseInt(request.getParameter("songID").toString());
				List<Song> list = songDao.viewallsongs();
				model.addAttribute("songList", list);
			}
			catch(Exception e){
				List<Song> list = songDao.viewallsongs();
				model.addAttribute("songList", list);
				model.addAttribute("message", "Please Select to remove the song details");
				return "viewallsongs";
			}
			songDao.delete(songID);
			List<Song> list = songDao.viewallsongs();
			model.addAttribute("songList", list);
			model.addAttribute("message", "Successfully Deleted");
			return "removesong";
		
			}
		@RequestMapping(value = "/songupdate", method = RequestMethod.GET)
		public String updatesongdetails() {
			return "updatesongdetails";
		}

		@RequestMapping(value = "/updatesongdetails", method = RequestMethod.POST)
		public String updatesongdetails(HttpServletRequest request, Model model) {
			int songID;
		/*	String songCost;
			String rating;*/
			try {
				songID = Integer.parseInt(request.getParameter("songID").toString());
				
			} catch (Exception e) {
				model.addAttribute("message", "Song details not updated, please give valid input..");
				return "updatesongdetails";
			}
			Song song = new Song();
			song.setActive(true);
			String songCost =request.getParameter("songCost").toString();
			String rating = request.getParameter("rating").toString();
			song = songDao.updatesong(songID, songCost, rating);
			if (song == null) {
				model.addAttribute("message", "Invalid song id!!Not able to Update the UserCredentials");
				return "updatesongdetails";
			} else {
				model.addAttribute("song", song);
				model.addAttribute("message", "Song details has been updated successfully");
				return "updatesongdetails";
			}

}	
}