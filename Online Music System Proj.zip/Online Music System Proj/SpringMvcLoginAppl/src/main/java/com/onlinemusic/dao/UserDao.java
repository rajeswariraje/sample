package com.onlinemusic.dao;

import java.util.List;

import com.onlinemusic.model.User;

/**
 * @author Rajeswari
 *This class is used for implementing  User Methods
 */
public interface UserDao {
	
	public int register(User user);

	public String deleteuser(String userName);

	public List<User> viewAllusers();

	public User validateUser(User user);
	
	public User UserValidation(User user);

	public User updateusercredentials(User user);

	public List<User> search(String userName);

	public String removeuser(String userName);
	

}