package com.onlinemusic.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.onlinemusic.model.Song;



/**
 * @author Rajeswari
 *This class is used for Validation of songdetails
 */
public class SongValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return Song.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		Song song = (Song) target;
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "songID", "error.songID", "*please enter  SongID");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "songName", "error.songName", "*please enter  SongName ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "songType", "error.songType", "*please enter  SongType ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "songCost", "error.songCost", "*please enter  SongCost ");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "songDuration", "error.songDuration","*please enter SongDuration");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "movieName", "error.movieName","*please enter MovieName");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "rating", "error.rating", "*please enter  Rating");
		
		if(errors.getFieldError("songName") == null && song.getSongName().length()<2) {
			errors.rejectValue("songName", "error.songName", "songName length should be greater than 1");
	}
		
		if(errors.getFieldError("movieName") == null && song.getMovieName().length()<2) {
			errors.rejectValue("movieName", "error.movieName", "MovieName length should be greater than 1");
	}
	

}}
