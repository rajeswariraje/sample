package com.onlinemusic.dao;

import java.util.List;

import com.onlinemusic.model.Song;


/**
 * @author Rajeswari
 *This Class is used for implementing Song Methods
 */
public interface SongDao {

	public int songregister(Song song);

	public Song delete(int songID);

	public List<Song> viewallsongs();

	public Song viewsong(int songID);

	public Song updatesong(int songID, String songCost, String rating);
	
	public Song update(int songID, String songCost, String rating);
	
	
	public String removesong(int songID);

	
}
