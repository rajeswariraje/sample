package com.onlinemusic.daoImpl;

import java.util.List;


import javax.persistence.Query;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import org.springframework.stereotype.Repository;

import com.onlinemusic.Utility.HibernateUtil;
import com.onlinemusic.dao.PurchaseDao;
import com.onlinemusic.model.Purchase;
import com.onlinemusic.model.Song;
import com.onlinemusic.model.User;
@SuppressWarnings("unchecked")
@Repository
public class PurchaseDaoImpl implements PurchaseDao {

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public List<Purchase>viewallyourpurchasedsongs(String userName) {		//Displaying All the Purchased Songs of the User
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userName like :userName");
		query.setParameter("userName",userName);
		List<User> users=query.getResultList();
		User user = users.size() > 0 ? users.get(0) : null;
		if (user == null) {
			return null;
		} else {
			Query sql = session.createQuery("from Purchase where user=:userName");
			sql.setParameter("userName", user);
			List<Purchase> list = sql.getResultList();
			return list;
		}
	}

	@Override
	public Purchase purchase(String userName, Song song) { 				//Purchasing Songs using UserName
		
		List<Purchase> listPurchase = viewallyourpurchasedsongs(userName);
		if(listPurchase != null && listPurchase.size() != 0 ) {
			for(Purchase pur : listPurchase) {
				if(pur.getSong().equals(song)) {
					return null;
				}
			}
		}
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		Query query = session.createQuery("from User where userName like :userName");
		query.setParameter("userName",userName);
		List<User> users=query.getResultList();
		User user = users.size() > 0 ? users.get(0) : null;
		Purchase purchase = new Purchase();
		purchase.setSong(song);
		purchase.setUser(user);
		session.save(purchase);
		tr.commit();
		session.close();
		return purchase;
	}

	@Override
	public List<Purchase> viewpurchasedsongs(String userName) {		//View the Purchased songs of the user 
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from User where userName like :userName");
		query.setParameter("userName",userName);
		List<User> users=query.getResultList();
		User user = users.size() > 0 ? users.get(0) : null;
		if (user == null) {
			return null;
		} else {
			Query sql = session.createQuery("from Purchase where user=:userName");
			sql.setParameter("userName", user);
			List<Purchase> list = sql.getResultList();
			return list;
		}
	}


	
	}

