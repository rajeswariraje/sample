package com.onlinemusic.dao;

import java.util.List;

import com.onlinemusic.model.Purchase;
import com.onlinemusic.model.Song;

/**
 * @author Rajeswari
 *This class is used for Implementing Purchase Methods
 */
public interface PurchaseDao {
	
	public List<Purchase> viewallyourpurchasedsongs(String userName);

	public Purchase purchase(String userName, Song song);

	public List<Purchase> viewpurchasedsongs(String userName);

}
