package com.jouve.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.jouve.model.User;

public class LoginValidator implements Validator {
	@Override
	public boolean supports(Class<?> clazz) {

		return User.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {

		User login = (User) target;

		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "userName", "error.userName", "username is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "password", "error.password", "password is required");

		if(errors.getFieldError("userName") == null && login.getUserName().length() < 3) {
			errors.rejectValue("userName", "error.userName", "username lengh should be greater than 3");
		}
	}

}
