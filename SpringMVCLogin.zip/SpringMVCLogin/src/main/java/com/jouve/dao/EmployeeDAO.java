package com.jouve.dao;

import com.jouve.model.Employee;


public interface EmployeeDAO {
	public int insertEmployee(Employee emp);
}
