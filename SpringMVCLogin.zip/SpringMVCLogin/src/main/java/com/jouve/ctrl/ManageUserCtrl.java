package com.jouve.ctrl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jouve.dao.UserDao;
import com.jouve.model.User;

@Controller
public class ManageUserCtrl {

	@Autowired
	UserDao userDao;

	@RequestMapping(value = "/viewAll", method=RequestMethod.GET)
	public String viewAll(Model model) {
		List<User> list = userDao.viewAll();
		//System.out.println(list);
		model.addAttribute("userList", list);
		return "viewAll";
	}

	@RequestMapping(value = "/search", method=RequestMethod.GET)
	public String searchGet(Model model) {
		model.addAttribute("");
		return "search";
	}

	@RequestMapping(value = "/search", method=RequestMethod.POST)
	public String searchPost(HttpServletRequest request, Model model) {
		String pathValue = request.getParameter("userName");
		List<User> list = userDao.searchByUserName(pathValue);
		//System.out.println(list);
		model.addAttribute("userList", list);
		return "viewAllEdit";
	}

	@RequestMapping(value = "/update", method=RequestMethod.POST)
	public String upadatePost(HttpServletRequest request, Model model) {
		int userId = Integer.parseInt(request.getParameter("userId").toString());
		User user = userDao.find(userId);
		model.addAttribute("user", user);
		return "update";
	}

	@RequestMapping(value = "/delete", method=RequestMethod.POST)
	public String deletePost(HttpServletRequest request, Model model) {
		int userId = Integer.parseInt(request.getParameter("userId").toString());
		userDao.delete(userId);
		model.addAttribute("message", "Successfully deleted");
		return "welcome";
	}

	@RequestMapping(value = "/updateUser", method=RequestMethod.POST)
	public String upadateUser(@ModelAttribute("user") User user, Model model) {
		userDao.update(user);
		model.addAttribute("message", "Successfully updated");
		return "welcome";
	}

	@RequestMapping(value="/find/{userId}", method=RequestMethod.GET)
	public String findUser(@PathVariable("userId") Integer userId, Model model) {
		User user = userDao.find(userId);
		model.addAttribute("user", user);
		return "find";
	}
}
