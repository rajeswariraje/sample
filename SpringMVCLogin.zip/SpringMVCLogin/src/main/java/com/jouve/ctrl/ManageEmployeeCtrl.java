package com.jouve.ctrl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.jouve.dao.EmployeeDAO;
import com.jouve.model.Employee;

@Controller
public class ManageEmployeeCtrl {

	@Autowired
	EmployeeDAO employeeDao;

	@RequestMapping(value="/employeeregister", method = RequestMethod.GET)
	public String register(Model model) {
		model.addAttribute("employee", new Employee());
		return "employeeregister";
	}

	@RequestMapping(value="/employeeregister", method = RequestMethod.POST)
	public String addUser(@ModelAttribute("employee") Employee employee, BindingResult result, Model model) {

		/*Address adr = new Address();

		adr.setCity("chennai");
		adr.setCity("Tamilandu");
		List<Address> listAdr = new ArrayList<Address>();
		listAdr.add(adr);
		employee.setAddr(listAdr);*/

		int pk = employeeDao.insertEmployee(employee);

		model.addAttribute("message", employee.getName() + " successfully created with primary key: "+pk);
		return "welcome";
	}
}
