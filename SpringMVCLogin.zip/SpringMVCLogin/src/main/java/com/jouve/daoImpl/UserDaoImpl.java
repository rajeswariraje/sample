package com.jouve.daoImpl;


import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.hibernate.query.QueryProducer;
import org.springframework.stereotype.Repository;

import com.jouve.dao.UserDao;
import com.jouve.model.User;
import com.jouve.utility.HibernateUtil;

@Repository
public class UserDaoImpl implements UserDao{

	SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public int register(User user) {

		/*String sql = "insert into users values(?,?,?,?,?,?,?)";
		Object[] parameter = {user.getUserName(), user.getPassword(), user.getFirstName(), user.getLastName(), user.getEmail(),
				user.getAddress(), user.getPhone()};
		return jdbcTemplate.update(sql,parameter);*/

		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int pk = 0;
		try {
			pk = (int) session.save(user);
			tr.commit();
		} catch(Exception e) {
			tr.rollback();
			System.err.println("Failed to insert "+e);
		} finally {
			session.close();
		}
		return pk;

	}

	@Override
	public User validateUser(User user) {
		/*String sql = "select * from users where username='" + user.getUserName() + "' and password='" + user.getPassword()
        + "'";
		List<User> users = jdbcTemplate.query(sql, new UserMapper());
		return users.size() > 0 ? users.get(0) : null;*/

		Session session = sessionFactory.openSession();
		Transaction tr =  session.beginTransaction();

		//Using criteria
		/*Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.eq("userName", user.getUserName()));
		cr.add(Restrictions.eq("password", user.getPassword()));
		List<User> users = cr.list();*/

		//Using Query
		Query query = session.createQuery("from User where userName= :username and password=:password");
		query.setParameter("username", user.getUserName());
		query.setParameter("password", user.getPassword());
		List<User> users = query.getResultList();
		tr.commit();
		session.close();
		return users.size() > 0 ? users.get(0) : null;
	}

	@Override
	public List<User> viewAll() {
		Session session = sessionFactory.openSession();
		//Criteria cr = session.createCriteria(User.class);
		//List<User> list = cr.list();
		List list = session.createQuery("from User").list();
		return list;
	}

	@Override
	public List<User> searchByUserName(String userName){

		Session session = sessionFactory.openSession();

		Criteria cr = session.createCriteria(User.class);
		cr.add(Restrictions.like("userName", "%"+userName+"%"));
		List<User> users = cr.list();

		return users;
	}

	public User find(Integer id) {
		Session session = sessionFactory.openSession();
		/*User user = session.load(User.class, id);*/
		String sqlString = "select id, address, email, first_name, last_name, phone, user_name from users where id="+id;
		Query query = session.createNativeQuery(sqlString);
		List<Object[]> data = query.getResultList();
		User user = new User();
		for(Object[] row : data) {
            //Map row = (Map)object;
            //System.out.println("First Name: " + row[0]);
            //System.out.println("Email: " + row[1]);
			user.setId(Integer.parseInt(row[0].toString()));
			user.setAddress(row[1].toString());
			user.setEmail(row[2].toString());
			user.setFirstName(row[3].toString());
			user.setLastName(row[4].toString());
			user.setPhone(row[5].toString());
			user.setUserName(row[6].toString());
         }
		//System.out.println(data);
		return user;
	}

	public void update(User user) {
		Session session = sessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		try {
			session.update(user);
			tr.commit();
		} catch(Exception e) {
			tr.rollback();
			System.err.println("Failed to update "+e);
		} finally {
			session.close();
		}
	}

	public void delete(int userId) {
		Session session = sessionFactory.openSession();
		Transaction tr =  session.beginTransaction();
		User user = session.get(User.class, userId);
		session.delete(user);
		tr.commit();
		session.close();
	}
}