package com.jouve.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.jouve.dao.EmployeeDAO;
import com.jouve.model.Employee;
import com.jouve.utility.HibernateUtil;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

	SessionFactory SessionFactory = HibernateUtil.getSessionFactory();

	@Override
	public int insertEmployee(Employee emp) {
		Session session = SessionFactory.openSession();
		Transaction tr = session.beginTransaction();
		int pk = (int)session.save(emp);
		session.flush();
		tr.commit();
		session.close();
		return pk;
	}

}
